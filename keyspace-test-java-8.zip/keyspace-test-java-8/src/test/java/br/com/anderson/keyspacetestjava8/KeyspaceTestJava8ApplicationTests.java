package br.com.anderson.keyspacetestjava8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeyspaceTestJava8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
